# Project-Classroom-Mangement-System
Project Name: Classroom Management System

Team Members:
1. Tasnim Ferdous Anan, 180041108
2. Farhan Ishmam, 180041120
3. Asir Saadat Nipur, 180041127

Motivation & Objective:  
We often experience difficulty in getting the proper classroom for a particular class lecture or quiz. The requirements for a classroom vary section to section. Some of the classrooms remain unoccupied after classes are cancelled. Sometimes two sections have to stand in front of their classrooms waiting for their teachers to decide who will take the class. That’s because the information of each and every classroom isn’t carried out by a single medium and we want to create that medium using C++ which will relay this information to the class representatives as well as teachers in order to arrange a classroom.

Targeted Customer(s): 
Educational institutions

Features: 
We are trying to implement a management system which will
-	Keep track of the current information of a classroom and update them
-	Display the information in three views for students, class representatives and teachers.
-	Keep records of student attendance and marks
-	Graphically present the data to the users

So far, we have decided to implement the above features. In the future, we want to incorporate this system with other management systems under the same institution.	-  
